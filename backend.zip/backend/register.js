const express = require("express");
const router = express.Router();
const db = require("./db");

router.post("/", (req, res) => {
    const { username, password } = req.body;

    const sql =
        "INSERT INTO users (username, password) VALUES (?, ?)";

    db.query(sql, [username, password], (error) => {
        if (error) {
            console.log(error);
            return res.send("false");
        }

        res.send("true");
    });
});

module.exports = router;