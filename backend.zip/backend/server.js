const express = require("express");
const cors = require("cors");
const bodyparser = require("body-parser");

const registerroute = require("./register");
const loginroute = require("./login");


const app = express();

app.use(cors());
app.use(bodyparser.json());

app.use("/register", registerroute);
app.use("/login", loginroute);


app.listen(3000, () => {
    console.log("Server fut: http://localhost:3000");
});