const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "kepszerkeszto"
});

db.connect(err => {
    if (err) {
        console.error("ERROR:", err);
    } else {
        console.log("Az adatbázis elindult.");
    }
});

module.exports = db;