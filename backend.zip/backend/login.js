const express = require("express");
const router = express.Router();
const db = require("./db");

router.post("/", (req, res) => {
    const { username, password } = req.body;

    const sql =
        "SELECT * FROM users WHERE username = ? AND password = ?";

    db.query(sql, [username, password], (error, result) => {
        if (error) {
            console.log(error);
            return res.send("false");
        }

        if (result.length > 0) {
            res.send("true");
        } else {
            res.send("false");
        }
    });
});

module.exports = router;