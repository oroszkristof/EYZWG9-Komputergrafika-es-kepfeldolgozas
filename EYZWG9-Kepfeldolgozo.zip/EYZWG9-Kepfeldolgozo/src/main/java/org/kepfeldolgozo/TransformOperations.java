package org.kepfeldolgozo;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class TransformOperations {

    public static Image rotate90(Image image) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(height, width);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                pixelwriter.setColor(
                        ycoordinate,
                        width - xcoordinate - 1,
                        pixelreader.getColor(xcoordinate, ycoordinate)
                );
            }
        }

        return outputimage;
    }

    public static Image mirror(Image image) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                pixelwriter.setColor(
                        width - xcoordinate - 1,
                        ycoordinate,
                        pixelreader.getColor(xcoordinate, ycoordinate)
                );
            }
        }

        return outputimage;
    }

    public static Image rotateangle(Image image, double anglevalue) {

        double angle = Math.toRadians(anglevalue);

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        int centerx = width / 2;
        int centery = height / 2;

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                int sourcex = (int) (
                        Math.cos(angle) * (xcoordinate - centerx)
                                + Math.sin(angle) * (ycoordinate - centery)
                                + centerx
                );

                int sourcey = (int) (
                        -Math.sin(angle) * (xcoordinate - centerx)
                                + Math.cos(angle) * (ycoordinate - centery)
                                + centery
                );

                if (
                        sourcex >= 0 && sourcex < width &&
                                sourcey >= 0 && sourcey < height
                ) {
                    pixelwriter.setColor(
                            xcoordinate,
                            ycoordinate,
                            pixelreader.getColor(sourcex, sourcey)
                    );
                } else {
                    pixelwriter.setColor(
                            xcoordinate,
                            ycoordinate,
                            Color.BLACK
                    );
                }
            }
        }

        return outputimage;
    }

    public static Image resize(Image image, int newwidth, int newheight) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(newwidth, newheight);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < newwidth; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < newheight; ycoordinate++) {

                int sourcex = xcoordinate * width / newwidth;
                int sourcey = ycoordinate * height / newheight;

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        pixelreader.getColor(sourcex, sourcey)
                );
            }
        }

        return outputimage;
    }
}