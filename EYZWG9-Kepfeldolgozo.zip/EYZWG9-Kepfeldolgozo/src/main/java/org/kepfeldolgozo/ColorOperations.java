package org.kepfeldolgozo;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class ColorOperations {

    public static Image togray(Image image) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                double grayvalue =
                        pixelreader.getColor(xcoordinate, ycoordinate).getBrightness();

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        new Color(grayvalue, grayvalue, grayvalue, 1)
                );
            }
        }

        return outputimage;
    }

    public static Image toblackwhite(Image image) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                double brightnessvalue =
                        pixelreader.getColor(xcoordinate, ycoordinate).getBrightness();

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        brightnessvalue > 0.5 ? Color.WHITE : Color.BLACK
                );
            }
        }

        return outputimage;
    }

    public static Image redchannel(Image image) {
        return colorchannel(image, 0);
    }

    public static Image greenchannel(Image image) {
        return colorchannel(image, 1);
    }

    public static Image bluechannel(Image image) {
        return colorchannel(image, 2);
    }

    private static Image colorchannel(Image image, int channeltype) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                Color color = pixelreader.getColor(xcoordinate, ycoordinate);

                if (channeltype == 0) {
                    pixelwriter.setColor(
                            xcoordinate,
                            ycoordinate,
                            new Color(color.getRed(), 0, 0, 1)
                    );
                }

                if (channeltype == 1) {
                    pixelwriter.setColor(
                            xcoordinate,
                            ycoordinate,
                            new Color(0, color.getGreen(), 0, 1)
                    );
                }

                if (channeltype == 2) {
                    pixelwriter.setColor(
                            xcoordinate,
                            ycoordinate,
                            new Color(0, 0, color.getBlue(), 1)
                    );
                }
            }
        }

        return outputimage;
    }

    public static Image adjustbrightness(Image image, double brightnessvalue) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                Color color = pixelreader.getColor(xcoordinate, ycoordinate);

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        new Color(
                                clamp(color.getRed() + brightnessvalue),
                                clamp(color.getGreen() + brightnessvalue),
                                clamp(color.getBlue() + brightnessvalue),
                                1
                        )
                );
            }
        }

        return outputimage;
    }

    public static Image adjustcontrast(Image image, double contrastvalue) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {
            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                Color color = pixelreader.getColor(xcoordinate, ycoordinate);

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        new Color(
                                clamp((color.getRed() - 0.5) * contrastvalue + 0.5),
                                clamp((color.getGreen() - 0.5) * contrastvalue + 0.5),
                                clamp((color.getBlue() - 0.5) * contrastvalue + 0.5),
                                1
                        )
                );
            }
        }

        return outputimage;
    }

    private static double clamp(double value) {
        return Math.clamp(value, 0, 1);
    }
}