package org.kepfeldolgozo;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.io.File;

public class ImageOperations {

    public static Image openimage(Stage stage) {

        FileChooser filechooser = new FileChooser();
        filechooser.setTitle("Kép megnyitása");

        filechooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter(
                        "Képfájlok",
                        "*.png",
                        "*.jpg",
                        "*.jpeg",
                        "*.bmp"
                )
        );

        File selectedfile = filechooser.showOpenDialog(stage);

        if (selectedfile != null) {
            return new Image(selectedfile.toURI().toString());
        }

        return null;
    }

    public static void saveimage(Image image, Stage stage) {

        try {
            FileChooser filechooser = new FileChooser();
            filechooser.setTitle("Kép mentése");

            filechooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter(
                            "PNG fájl",
                            "*.png"
                    )
            );

            File selectedfile = filechooser.showSaveDialog(stage);

            if (selectedfile != null) {
                ImageIO.write(
                        SwingFXUtils.fromFXImage(image, null),
                        "png",
                        selectedfile
                );
            }

        } catch (Exception exception) {
            AlertHelper.showerror("Mentési hiba!");
        }
    }
}