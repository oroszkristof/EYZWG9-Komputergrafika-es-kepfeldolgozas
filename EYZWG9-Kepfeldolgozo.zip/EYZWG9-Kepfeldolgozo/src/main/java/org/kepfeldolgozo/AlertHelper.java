package org.kepfeldolgozo;

import javafx.scene.control.Alert;

public class AlertHelper {

    public static void showerror(String message) {

        Alert alert = new Alert(Alert.AlertType.ERROR);

        alert.setHeaderText(null);
        alert.setContentText(message);

        alert.showAndWait();
    }
}