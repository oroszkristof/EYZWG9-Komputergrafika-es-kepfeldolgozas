package org.kepfeldolgozo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AuthService {

    public static boolean login(String username, String password) {
        return sendrequest("http://localhost:3000/login", username, password);
    }

    public static boolean register(String username, String password) {
        return sendrequest("http://localhost:3000/register", username, password);
    }

    private static boolean sendrequest(String urlstring, String username, String password) {

        try {
            URL url = new URL(urlstring);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            String json =
                    "{"
                            + "\"username\":\"" + username + "\","
                            + "\"password\":\"" + password + "\""
                            + "}";

            OutputStream outputstream = connection.getOutputStream();
            outputstream.write(json.getBytes());
            outputstream.flush();
            outputstream.close();

            BufferedReader bufferedreader =
                    new BufferedReader(
                            new InputStreamReader(connection.getInputStream())
                    );

            String response = bufferedreader.readLine();

            return response.contains("true");

        } catch (Exception exception) {
            return false;
        }
    }
}