package org.kepfeldolgozo;

import javafx.application.Application;
import javafx.stage.Stage;
import org.kepfeldolgozo.LoginView;

public class Main extends Application {

    @Override
    public void start(Stage stage) {

        new LoginView(stage);
    }

    public static void main(String[] args) {

        launch();
    }
}