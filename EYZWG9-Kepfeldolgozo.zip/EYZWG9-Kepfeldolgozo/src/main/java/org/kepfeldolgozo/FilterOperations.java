package org.kepfeldolgozo;

import javafx.scene.image.Image;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class FilterOperations {

    public static Image blur(Image image, int radius) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        radius = Math.max(1, radius);

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate++) {

            for (int ycoordinate = 0; ycoordinate < height; ycoordinate++) {

                double redsum = 0;
                double greensum = 0;
                double bluesum = 0;
                int pixelsum = 0;

                for (int horizontaloffset = -radius; horizontaloffset <= radius; horizontaloffset++) {

                    for (int verticaloffset = -radius; verticaloffset <= radius; verticaloffset++) {

                        int currentx = xcoordinate + horizontaloffset;
                        int currenty = ycoordinate + verticaloffset;

                        if (
                                currentx >= 0 && currentx < width &&
                                        currenty >= 0 && currenty < height
                        ) {

                            Color color = pixelreader.getColor(currentx, currenty);

                            redsum += color.getRed();
                            greensum += color.getGreen();
                            bluesum += color.getBlue();

                            pixelsum++;
                        }
                    }
                }

                pixelwriter.setColor(
                        xcoordinate,
                        ycoordinate,
                        new Color(
                                redsum / pixelsum,
                                greensum / pixelsum,
                                bluesum / pixelsum,
                                1
                        )
                );
            }
        }

        return outputimage;
    }

    public static Image mosaic(Image image, int blocksize) {

        int width = (int) image.getWidth();
        int height = (int) image.getHeight();

        WritableImage outputimage = new WritableImage(width, height);
        PixelReader pixelreader = image.getPixelReader();
        PixelWriter pixelwriter = outputimage.getPixelWriter();

        blocksize = Math.max(1, blocksize);

        for (int xcoordinate = 0; xcoordinate < width; xcoordinate += blocksize) {

            for (int ycoordinate = 0; ycoordinate < height; ycoordinate += blocksize) {

                Color color = pixelreader.getColor(xcoordinate, ycoordinate);

                for (int horizontaloffset = 0;
                     horizontaloffset < blocksize && xcoordinate + horizontaloffset < width;
                     horizontaloffset++) {

                    for (int verticaloffset = 0;
                         verticaloffset < blocksize && ycoordinate + verticaloffset < height;
                         verticaloffset++) {

                        pixelwriter.setColor(
                                xcoordinate + horizontaloffset,
                                ycoordinate + verticaloffset,
                                color
                        );
                    }
                }
            }
        }

        return outputimage;
    }
}