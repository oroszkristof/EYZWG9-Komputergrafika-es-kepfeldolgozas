package org.kepfeldolgozo;

import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;

public class CropOperations {

    public static Image crop(
            Image image,
            int startx,
            int starty,
            int width,
            int height
    ) {

        return new WritableImage(
                image.getPixelReader(),
                startx,
                starty,
                width,
                height
        );
    }
}