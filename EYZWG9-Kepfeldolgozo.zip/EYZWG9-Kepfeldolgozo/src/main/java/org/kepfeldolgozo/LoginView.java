package org.kepfeldolgozo;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginView {

    public LoginView(Stage primarystage) {

        Label titlelabel = new Label("KÉPSZERKESZTŐ ALKALMAZÁS");

        Label descriptionlabel = new Label(
                "Regisztráljon vagy lépjen be, majd válasszon egy képet és szerkessze kedve szerint."
        );

        titlelabel.setWrapText(false);
        descriptionlabel.setWrapText(false);

        titlelabel.setMaxWidth(Double.MAX_VALUE);
        descriptionlabel.setMaxWidth(Double.MAX_VALUE);

        titlelabel.setAlignment(Pos.CENTER);
        descriptionlabel.setAlignment(Pos.CENTER);

        titlelabel.setStyle("-fx-font-size:26px;-fx-text-fill:white;");
        descriptionlabel.setStyle("-fx-text-fill:#94a3b8;");

        TextField usernamefield = new TextField();
        PasswordField passwordfield = new PasswordField();

        usernamefield.setPromptText("Felhasználónév");
        passwordfield.setPromptText("Jelszó");

        Button loginbutton = new Button("BELÉPÉS");
        Button registerbutton = new Button("REGISZTRÁCIÓ");

        String buttonstyle =
                "-fx-background-color:#2563eb;" +
                        "-fx-text-fill:white;" +
                        "-fx-background-radius:10;";

        loginbutton.setStyle(buttonstyle);
        registerbutton.setStyle(buttonstyle);

        loginbutton.setMaxWidth(Double.MAX_VALUE);
        registerbutton.setMaxWidth(Double.MAX_VALUE);

        loginbutton.setOnAction(event -> {

            String username = usernamefield.getText();
            String password = passwordfield.getText();

            if (username.isEmpty() || password.isEmpty()) {

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Kérlek tölts ki minden mezőt!");
                alert.showAndWait();

                return;
            }

            boolean success = AuthService.login(username, password);

            if (success) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Sikeres belépés!");
                alert.showAndWait();

                new EditorView(primarystage, username);

            } else {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Hibás felhasználónév vagy jelszó!");
                alert.showAndWait();
            }
        });

        registerbutton.setOnAction(event -> {

            String username = usernamefield.getText();
            String password = passwordfield.getText();

            if (username.isEmpty() || password.isEmpty()) {

                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Kérlek tölts ki minden mezőt!");
                alert.showAndWait();

                return;
            }

            boolean success = AuthService.register(username, password);

            if (success) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Sikeres regisztráció!");
                alert.showAndWait();

            } else {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("");
                alert.setHeaderText(null);
                alert.setContentText("Ez a felhasználónév már létezik!");
                alert.showAndWait();
            }
        });

        VBox maincontainer = new VBox(
                15,
                titlelabel,
                descriptionlabel,
                usernamefield,
                passwordfield,
                loginbutton,
                registerbutton
        );

        maincontainer.setAlignment(Pos.CENTER);
        maincontainer.setMaxWidth(600);

        BorderPane rootlayout = new BorderPane(maincontainer);
        rootlayout.setStyle("-fx-background-color:#020617;");

        primarystage.setScene(new Scene(rootlayout, 1000, 600));
        primarystage.show();
    }
}