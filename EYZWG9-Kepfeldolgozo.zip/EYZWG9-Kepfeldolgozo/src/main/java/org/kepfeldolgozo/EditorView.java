package org.kepfeldolgozo;

import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.Stack;

public class EditorView {

    private final Stage stage;
    private final String username;
    private final ImageView imageview = new ImageView();

    private Image originalimage;
    private Image currentimage;

    private final Stack<Image> imagehistory = new Stack<>();

    private final Slider brightnessslider = new Slider(-0.5, 0.5, 0);
    private final Slider contrastslider = new Slider(0.5, 2, 1);
    private final Slider blurslider = new Slider(1, 5, 1);
    private final Slider mosaicslider = new Slider(1, 30, 1);
    private final Slider rotationslider = new Slider(0, 360, 0);

    private final TextField widthfield = new TextField();
    private final TextField heightfield = new TextField();

    private double startx;
    private double starty;

    public EditorView(Stage stage, String username) {
        this.stage = stage;
        this.username = username;
        showeditor();
    }

    private void showeditor() {

        MenuBar menubar = new MenuBar();

        Menu filemenu = new Menu("FÁJL");
        Menu operationsmenu = new Menu("MŰVELETEK");
        Menu colorsmenu = new Menu("SZÍNEK");
        Menu channelsmenu = new Menu("CSATORNÁK");

        MenuItem resetitem = new MenuItem("Visszaállítás");
        MenuItem undoitem = new MenuItem("Vissza");

        MenuItem mirroritem = new MenuItem("Tükrözés");
        MenuItem cropitem = new MenuItem("Kivágás");

        MenuItem grayitem = new MenuItem("Szürke");
        MenuItem blackwhiteitem = new MenuItem("Fekete-fehér");
        MenuItem coloritem = new MenuItem("Színes");

        MenuItem reditem = new MenuItem("Piros");
        MenuItem greenitem = new MenuItem("Zöld");
        MenuItem blueitem = new MenuItem("Kék");

        filemenu.getItems().addAll(resetitem, undoitem);
        operationsmenu.getItems().addAll(mirroritem, cropitem);
        colorsmenu.getItems().addAll(grayitem, blackwhiteitem, coloritem);
        channelsmenu.getItems().addAll(reditem, greenitem, blueitem);

        menubar.getMenus().addAll(filemenu, operationsmenu, colorsmenu, channelsmenu);

        VBox leftpanel = new VBox(15);
        leftpanel.setStyle("-fx-background-color:#0f172a;-fx-padding:20;");
        leftpanel.setPrefWidth(200);

        Label welcomelabel = new Label("Üdv, " + username + "!");
        welcomelabel.setStyle("-fx-text-fill:white;-fx-font-size:16px;-fx-font-weight:bold;");

        Button newimagebutton = new Button("ÚJ KÉP");
        Button savebutton = new Button("MENTÉS");
        Button logoutbutton = new Button("KIJELENTKEZÉS");

        String buttonstyle =
                "-fx-background-color:#1e293b;" +
                        "-fx-text-fill:white;" +
                        "-fx-background-radius:10;" +
                        "-fx-padding:12;" +
                        "-fx-font-weight:bold;";

        newimagebutton.setStyle(buttonstyle);
        savebutton.setStyle(buttonstyle);
        logoutbutton.setStyle(buttonstyle);

        newimagebutton.setMaxWidth(Double.MAX_VALUE);
        savebutton.setMaxWidth(Double.MAX_VALUE);
        logoutbutton.setMaxWidth(Double.MAX_VALUE);

        leftpanel.getChildren().addAll(
                welcomelabel,
                newimagebutton,
                savebutton,
                logoutbutton
        );

        VBox rightpanel = new VBox(15);
        rightpanel.setStyle("-fx-background-color:#0f172a;-fx-padding:20;");
        rightpanel.setPrefWidth(250);

        Label brightnesslabel = new Label("Fényerő");
        Label contrastlabel = new Label("Kontraszt");
        Label blurlabel = new Label("Homályosítás");
        Label mosaiclabel = new Label("Mozaik");
        Label rotationlabel = new Label("Forgatás");
        Label sizelabel = new Label("Méret");

        for (Label label : new Label[]{
                brightnesslabel,
                contrastlabel,
                blurlabel,
                mosaiclabel,
                rotationlabel,
                sizelabel
        }) {
            label.setStyle("-fx-text-fill:white;");
        }

        widthfield.setPromptText("Szélesség");
        heightfield.setPromptText("Magasság");

        Button resizebutton = new Button("Átméretezés");
        resizebutton.setStyle(buttonstyle);
        resizebutton.setMaxWidth(Double.MAX_VALUE);

        rightpanel.getChildren().addAll(
                brightnesslabel, brightnessslider,
                contrastlabel, contrastslider,
                blurlabel, blurslider,
                mosaiclabel, mosaicslider,
                rotationlabel, rotationslider,
                sizelabel, widthfield, heightfield, resizebutton
        );

        imageview.setFitWidth(700);
        imageview.setPreserveRatio(true);

        StackPane centerpanel = new StackPane(imageview);
        centerpanel.setAlignment(Pos.CENTER);
        centerpanel.setStyle("-fx-background-color:#020617;-fx-padding:20;");

        BorderPane rootlayout = new BorderPane();
        rootlayout.setTop(menubar);
        rootlayout.setLeft(leftpanel);
        rootlayout.setCenter(centerpanel);
        rootlayout.setRight(rightpanel);
        rootlayout.setStyle("-fx-background-color:#020617;");

        resetitem.setOnAction(event -> resetimage());
        undoitem.setOnAction(event -> undoimage());

        newimagebutton.setOnAction(event -> openimage());
        savebutton.setOnAction(event -> saveimage());
        logoutbutton.setOnAction(event -> new LoginView(stage));

        mirroritem.setOnAction(event -> mirrorimage());
        cropitem.setOnAction(event -> enablecrop());

        grayitem.setOnAction(event -> applygray());
        blackwhiteitem.setOnAction(event -> applyblackwhite());
        coloritem.setOnAction(event -> resetimage());

        reditem.setOnAction(event -> applyredchannel());
        greenitem.setOnAction(event -> applygreenchannel());
        blueitem.setOnAction(event -> applybluechannel());

        brightnessslider.setOnMousePressed(event -> savehistory());
        contrastslider.setOnMousePressed(event -> savehistory());
        blurslider.setOnMousePressed(event -> savehistory());
        mosaicslider.setOnMousePressed(event -> savehistory());
        rotationslider.setOnMousePressed(event -> savehistory());

        brightnessslider.valueProperty().addListener((o, ov, nv) -> applybrightness());
        contrastslider.valueProperty().addListener((o, ov, nv) -> applycontrast());
        blurslider.valueProperty().addListener((o, ov, nv) -> applyblur());
        mosaicslider.valueProperty().addListener((o, ov, nv) -> applymosaic());
        rotationslider.valueProperty().addListener((o, ov, nv) -> applyrotationangle());

        resizebutton.setOnAction(event -> resizeimage());

        stage.setScene(new Scene(rootlayout, 1200, 700));
        stage.show();
    }



    private void openimage() {
        Image selectedimage = ImageOperations.openimage(stage);

        if (selectedimage != null) {
            originalimage = selectedimage;
            currentimage = selectedimage;
            imageview.setImage(currentimage);
            imagehistory.clear();
            resetsliders();
        }
    }

    private void saveimage() {
        if (currentimage != null) {
            ImageOperations.saveimage(currentimage, stage);
        }
    }

    private void savehistory() {
        if (currentimage != null) {
            imagehistory.push(currentimage);
        }
    }

    private void undoimage() {
        if (!imagehistory.isEmpty()) {
            currentimage = imagehistory.pop();
            imageview.setImage(currentimage);
        }
    }

    private void resetimage() {
        if (originalimage != null) {
            currentimage = originalimage;
            imageview.setImage(currentimage);
            resetsliders();
        }
    }

    private void resetsliders() {
        brightnessslider.setValue(0);
        contrastslider.setValue(1);
        blurslider.setValue(1);
        mosaicslider.setValue(1);
        rotationslider.setValue(0);
    }

    private void mirrorimage() {
        if (currentimage != null) {
            savehistory();
            currentimage = TransformOperations.mirror(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applygray() {
        if (currentimage != null) {
            savehistory();
            currentimage = ColorOperations.togray(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applyblackwhite() {
        if (currentimage != null) {
            savehistory();
            currentimage = ColorOperations.toblackwhite(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applyredchannel() {
        if (currentimage != null) {
            savehistory();
            currentimage = ColorOperations.redchannel(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applygreenchannel() {
        if (currentimage != null) {
            savehistory();
            currentimage = ColorOperations.greenchannel(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applybluechannel() {
        if (currentimage != null) {
            savehistory();
            currentimage = ColorOperations.bluechannel(currentimage);
            imageview.setImage(currentimage);
        }
    }

    private void applybrightness() {
        if (originalimage != null) {
            currentimage = ColorOperations.adjustbrightness(
                    originalimage,
                    brightnessslider.getValue()
            );
            imageview.setImage(currentimage);
        }
    }

    private void applycontrast() {
        if (originalimage != null) {
            currentimage = ColorOperations.adjustcontrast(
                    originalimage,
                    contrastslider.getValue()
            );
            imageview.setImage(currentimage);
        }
    }

    private void applyblur() {
        if (originalimage != null) {
            currentimage = FilterOperations.blur(
                    originalimage,
                    (int) blurslider.getValue()
            );
            imageview.setImage(currentimage);
        }
    }

    private void applymosaic() {
        if (originalimage != null) {
            currentimage = FilterOperations.mosaic(
                    originalimage,
                    (int) mosaicslider.getValue()
            );
            imageview.setImage(currentimage);
        }
    }

    private void applyrotationangle() {
        if (originalimage != null) {
            currentimage = TransformOperations.rotateangle(
                    originalimage,
                    rotationslider.getValue()
            );
            imageview.setImage(currentimage);
        }
    }

    private void resizeimage() {

        if (currentimage == null) {
            return;
        }

        try {
            int newwidth = Integer.parseInt(widthfield.getText());
            int newheight = Integer.parseInt(heightfield.getText());

            if (newwidth > 0 && newheight > 0) {

                savehistory();

                currentimage = TransformOperations.resize(
                        currentimage,
                        newwidth,
                        newheight
                );

                imageview.setImage(currentimage);
            }

        } catch (Exception exception) {
            AlertHelper.showerror("Hibás méret!");
        }
    }

    private void enablecrop() {

        if (currentimage == null) {
            return;
        }

        imageview.setCursor(Cursor.CROSSHAIR);

        imageview.setOnMousePressed(event -> {
            startx = event.getX();
            starty = event.getY();
        });

        imageview.setOnMouseReleased(event -> {

            if (currentimage == null) {
                return;
            }

            double endx = event.getX();
            double endy = event.getY();

            int imagewidth = (int) currentimage.getWidth();
            int imageheight = (int) currentimage.getHeight();

            double displayedwidth = imageview.getBoundsInLocal().getWidth();
            double displayedheight = imageview.getBoundsInLocal().getHeight();

            int cropx = (int) (Math.min(startx, endx) * imagewidth / displayedwidth);
            int cropy = (int) (Math.min(starty, endy) * imageheight / displayedheight);
            int cropwidth = (int) (Math.abs(startx - endx) * imagewidth / displayedwidth);
            int cropheight = (int) (Math.abs(starty - endy) * imageheight / displayedheight);

            cropx = Math.max(0, Math.min(cropx, imagewidth - 1));
            cropy = Math.max(0, Math.min(cropy, imageheight - 1));
            cropwidth = Math.max(1, Math.min(cropwidth, imagewidth - cropx));
            cropheight = Math.max(1, Math.min(cropheight, imageheight - cropy));

            savehistory();

            currentimage = CropOperations.crop(
                    currentimage,
                    cropx,
                    cropy,
                    cropwidth,
                    cropheight
            );

            imageview.setImage(currentimage);

            imageview.setCursor(Cursor.DEFAULT);
            imageview.setOnMousePressed(null);
            imageview.setOnMouseReleased(null);
        });
    }
}